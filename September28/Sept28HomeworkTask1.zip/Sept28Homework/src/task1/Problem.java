package task1;
// Задание 1.
//Создайте Package (щелчок правой кнопкой мыши на папке src -> New -> Package).
//1 В созданном пакете создайте класс Автомобиль. Создайте поля для типа автомобиля –
// грузовик, спорткар, легковой (можно сделать перечисление), мощность двигателя (сколько лошадиных сил),
// поля для марки и модели автомобиля. Одно из полей сделайте публичным, второе – без модификатора доступа,
// остальные – приватными. Создайте объект этого класса в программе и попробуйте установить значения для полей.
// Какие поля возможно установить? Для приватных полей напишите геттеры и сеттеры.
//2 Создайте класс Завод. Класс будет производить три вида автомобилей (иметь 3 метода) –
// спорткар, грузовик, легковой. В основной программе создайте несколько автомобилей с помощью класса Завод.




// Было озвучено, что не запрещено модифицировать условие, поэтому мой класс не Автомобиль,
// а Проблема с соответствующими полями.
public class Problem {
    public String name;
    String description;
    private Complicity complicity;
    private boolean isSolvable;
    private int solvingTimeHours;


    //Для приватных полей напишите геттеры и сеттеры.
    public Problem(){

    }

    public Problem(String name,String description,boolean isSolvable,int solvingTimeHours,Complicity complicity) {
        this.name = name;
        this.description = description;
        this.complicity = complicity;
        this.isSolvable = isSolvable;
        this.solvingTimeHours = solvingTimeHours;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Complicity getComplicity() {
        return complicity;
    }

    public void setComplicity(Complicity complicity) {
        this.complicity = complicity;
    }

    public boolean isSolvable() {
        return isSolvable;
    }

    public void setSolvable(boolean solvable) {
        isSolvable = solvable;
    }

    public int getSolvingTimeHours() {
        return solvingTimeHours;
    }

    public void setSolvingTimeHours(int solvingTimeHours) {
        this.solvingTimeHours = solvingTimeHours;
    }


}
