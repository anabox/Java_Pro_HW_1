package task1;
//Создайте класс Завод. Класс будет производить три вида автомобилей (иметь 3 метода) –
//// спорткар, грузовик, легковой.


// В моём случае вместо завода я создаю класс МояЖизнь, которая создает Проблемы разной сложности
public class MyLife {
    public Problem createEasyProblem(String name, String description, boolean isSolvable, int solvingTimeHours) {
        return new Problem(name, description, isSolvable, solvingTimeHours, Complicity.EASY);
    }

    public Problem createMiddleProblem(String name, String description, boolean isSolvable, int solvingTimeHours) {
        return new Problem(name, description, isSolvable, solvingTimeHours, Complicity.MIDDLE);
    }

    public Problem createHardProblem(String name, String description, boolean isSolvable, int solvingTimeHours) {
        return new Problem(name, description, isSolvable, solvingTimeHours, Complicity.HARD);
    }

}
