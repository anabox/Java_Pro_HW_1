package task1;

public enum Complicity {
    EASY,
    MIDDLE,
    HARD
}
