import task1.MyLife;
import task1.Problem;

public class Main {
    public static void main(String[] args) {
        //Создайте объект этого класса в программе и попробуйте установить значения для полей.
        //// Какие поля возможно установить?

        Problem issueOne = new Problem();
        issueOne.name = "Отсутствие колбасы";

        //можно установить только name, у которого модификатор доступа public


        // В основной программе создайте несколько автомобилей с помощью класса Завод.
        // В моём случае в основной программе я создаю проблемы с помощью класса МояЖизнь.

        MyLife newLife = new MyLife();
        Problem problem1 = newLife.createEasyProblem("Домашнее задание", "очень лень делать", true, 3);
        Problem problem2 = newLife.createMiddleProblem("Цветы", "постоянно вянут", true, 1000);
        Problem problem3 = newLife.createHardProblem("Экзистенциальный кризис", "преисполнилась в своём познании, " +
                "будто проживаю сто триллионов лет.", false, 0);

        System.out.println(problem1.name+", которое "+problem1.getDescription()+". Еще и делать его целых "+problem1.getSolvingTimeHours()+" часа.");
        System.out.println(problem2.name+", которые "+problem2.getDescription()+". Еще и ухаживать за ними целых "+problem2.getSolvingTimeHours()+" часов.");
        System.out.println(problem3.name+", хоть я и "+problem3.getDescription());
    }
}