package task2;

public enum HumorSense {
    NOT_FUNNY,
    JOKES_AS_YOUR_DAD,
    TOLERABLE,
    FUNNY,
    STAND_UP_COMEDIAN

}
