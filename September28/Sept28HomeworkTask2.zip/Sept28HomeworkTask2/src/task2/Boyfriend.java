package task2;

public class Boyfriend {
    private String name;
    private int height;
    private int age;
    private HumorSense humorSense;

    public Boyfriend() {

    }

    public Boyfriend(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public Boyfriend(String name, int age, int height, HumorSense humorSense) {
        if (height < 170) throw new IllegalArgumentException("Прости, приятель,ты славный, но нам не по пути");
        this.name = name;
        this.age = age;
        this.height = height;
        this.humorSense = humorSense;
    }
    public Boyfriend(Boyfriend original){
        this.name = original.name;
        this.age = original.age;
        this.height = original.height;
        this.humorSense = original.humorSense;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        if (height < 170) throw new IllegalArgumentException("Прости, приятель,ты хороший, но не дотянешься");
        this.height = height;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public HumorSense getHumorSense() {
        return humorSense;
    }

    public void setHumorSense(HumorSense humorSense) {
        this.humorSense = humorSense;
    }

    public void drinkOneProsecco() {
        HumorSense[] values = HumorSense.values();
        int currentIndex = humorSense.ordinal();
        int nextIndex = currentIndex + 1;
        if (nextIndex > values.length - 1) throw new RuntimeException("Так,пора пить водичку,веселее он уже не станет");
        humorSense = values[nextIndex];
    }
}
