import java.sql.SQLOutput;

public class Pair {
    private String first;
    private String second;

    {
        System.out.println(getFirst());
        System.out.println(getSecond());
        first = "one";
        second = "two";
    }

    public Pair(){
        System.out.println(getFirst());
        System.out.println(getSecond());
    }

    public Pair(String first,String second){
        this.first = first;
        this.second = second;
        System.out.println(first);
        System.out.println(second);
    }
    public String getFirst() {
        return first;
    }

    public String getSecond() {
        return second;
    }



}
